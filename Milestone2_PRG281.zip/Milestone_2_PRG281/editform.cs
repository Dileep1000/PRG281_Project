﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Milestone_2_PRG281
{
    public partial class editform : Form
    {
        SqlConnection con = new SqlConnection("Data Source=DESKTOP-9K6ENBP\\SQLEXPRESS; Initial Catalog = Inventory; Integrated Security=True");
        SqlCommand command;
        SqlDataAdapter adpater;
        DataTable datatable;
        int ItemID;

        public editform()
        {
            InitializeComponent();
            ViewInventory();
        }

        private void editform_Load(object sender, EventArgs e)
        {

        }

        private void Btn_Add_Click(object sender, EventArgs e)
        {
            con.Open();
            command = new SqlCommand("insert into Inventorytable values('"+txt_itemCat.Text+"', '"+txt_itemName.Text+"', '"+txt_itemQuantity.Text+"', '"+txt_itemPrice.Text+"')", con);
            command.ExecuteNonQuery();
            MessageBox.Show("Data has been successfully added");
            con.Close();
            ViewInventory();
            Reset();
        }
        public void ViewInventory()
        {
            con.Open();
            adpater = new SqlDataAdapter("select * from Inventorytable", con);
            datatable = new DataTable();
            adpater.Fill(datatable);
            dataGridView1.DataSource = datatable;   
            con.Close();
        }
        public void Reset()
        {
            txt_itemCat.Text = " ";
            txt_itemName.Text = " ";
            txt_itemQuantity.Text = " ";
            txt_itemPrice.Text = " ";
        }

        private void dataGridView1_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            ItemID = Convert.ToInt32(dataGridView1.Rows[e.RowIndex].Cells[0].Value.ToString());
            txt_itemCat.Text = dataGridView1.Rows[e.RowIndex].Cells[1].Value.ToString();
            txt_itemName.Text = dataGridView1.Rows[e.RowIndex].Cells[2].Value.ToString();
            txt_itemQuantity.Text = dataGridView1.Rows[e.RowIndex].Cells[3].Value.ToString();
            txt_itemPrice.Text = dataGridView1.Rows[e.RowIndex].Cells[4].Value.ToString();
        }

        private void Btn_Update_Click(object sender, EventArgs e)
        {
            con.Open();
            command = new SqlCommand("update Inventorytable set ItemCategory = '" + txt_itemCat.Text + "', ItemName = '" + txt_itemName.Text + "'," +
                " Quantity = '" + txt_itemQuantity.Text + "', Price = '" + txt_itemPrice.Text + "'where ItemID = '"+ItemID+"'", con);
            command.ExecuteNonQuery();
            MessageBox.Show("Data has been successfully updated");            
            con.Close();
            ViewInventory();
        }

        private void Btn_Delete_Click(object sender, EventArgs e)
        {
            con.Open();
            command = new SqlCommand("Delete from Inventorytable where ItemID = '" + ItemID + "'", con);
            command.ExecuteNonQuery();
            MessageBox.Show("Data has been successfully removed");
            con.Close();
            ViewInventory();
        }

        private void Btn_Reset_Click(object sender, EventArgs e)
        {
            Action<Control.ControlCollection> func = null;
            func = (Controls) =>
            {
                foreach (Control control in Controls)
                {
                    if (control is TextBox )
                    {
                        (control as TextBox).Clear();
                    }
                    else
                    {
                        func(control.Controls);
                    }
                }
            };
            func(Controls);
        }
    }
}
