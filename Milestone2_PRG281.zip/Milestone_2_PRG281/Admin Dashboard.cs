﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Milestone_2_PRG281
{
    public partial class Admin_Dashboard : Form
    {
        public Admin_Dashboard()
        {
            InitializeComponent();
        }

        private void loadform(object Form)
        {
            if (this.Main.Controls.Count > 0)
                this.Main.Controls.RemoveAt(0);
            Form f = Form as Form;
            f.TopLevel = false;
            f.Dock = DockStyle.Fill;
            this.Main.Controls.Add(f);
            this.Main.Tag = f;
            f.Show();
        }

        private void Btn_EditItems_Click(object sender, EventArgs e)
        {
            loadform(new editform());
        }
        private void button1_Click(object sender, EventArgs e)
        {
            loadform(new Sales_Record());
        }

        private void Exit_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
